import RegistrationForm from './components/RegistrationForm.jsx';
import './App.css'

function App() {
  return (
    <div className="App">
      <RegistrationForm />
    </div>
  )
}

export default App
