import { useState } from 'react'
import reactLogo from './assets/react.svg'
import AddActicle from './components/AddArticle.jsx';
import './App.css'

function App() {


    return (
        <div className="App">
        <AddActicle />
        </div> 
  )
}

export default App
