import './App.css'
import ArticleManager from './components/ArticleManager.jsx'

function App() {
    return (
        <div className="App">
            <h1>Lab 4 task 2</h1>
            <ArticleManager />
        </div>
    )
}

export default App