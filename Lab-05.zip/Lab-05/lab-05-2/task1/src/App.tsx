import React from 'react';
import SearchApp from './components/SearchApp';
import './App.css';

function App() {
  return (
    <div className="App">
      <SearchApp />
    </div>
  );
}

export default App;