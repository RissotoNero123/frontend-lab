import UserProfile from './components/UserProfile';
import './App.css'

function App() {
  return (
    <div className="App">
      <UserProfile />
    </div>
  )
}

export default App
