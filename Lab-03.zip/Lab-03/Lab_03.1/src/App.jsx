import CounterApp from './components/CounterApp';
import './App.css'

function App() {
  return (
    <div className="App">
      <CounterApp />
    </div>
  )
}

export default App
